// Ordered catalog shared by selection, saved workouts and the searchable library.
window.VEXYRO_EXERCISES = Object.freeze([
  ...window.VEXYRO_HOME_EXERCISES,
  ...window.VEXYRO_GYM_EXERCISES,
]);
