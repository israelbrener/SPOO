// Human demonstration embeds verified against the publisher's VideoObject metadata.
// Hebrew instructions are concise adaptations; demo repetition defaults do not prescribe a load.
window.VEXYRO_GYM_EXERCISES = Object.freeze([
  {
    "id": "barbell-bench-press",
    "name": "לחיצת חזה במוט",
    "group": "chest",
    "level": "intermediate",
    "equipment": [
      "barbell",
      "bench"
    ],
    "equipmentLabel": "מוט, ספסל ומתקן בטיחות",
    "focus": [
      "חזה",
      "יד אחורית",
      "כתפיים"
    ],
    "description": "תרגיל לחיצה בשכיבה עם מוט חופשי, לחיזוק פלג הגוף העליון.",
    "steps": [
      "שכבו על הספסל עם כפות רגליים יציבות ואחיזה סגורה במוט, מעט מעבר לרוחב הכתפיים.",
      "שמרו את השכמות יציבות והורידו את המוט באטיות לכיוון החזה, בטווח שנשלט בנוחות.",
      "דחפו את המוט מעלה; בסיום החזירו אותו בבטחה למתקן."
    ],
    "cues": [
      "האגודלים סוגרים על המוט ושורשי כף היד נשארים יציבים.",
      "הישבן והשכמות נשארים במגע עם הספסל."
    ],
    "cautions": [
      {
        "title": "בטיחות מתחת למוט",
        "text": "אם אינכם מכירים את הטכניקה, תרגלו עם מדריך ומשגיח או מתקן בטיחות לפני הוספת עומס."
      },
      {
        "title": "כאב בכתף או בשורש כף היד",
        "text": "אם מופיע כאב, עצרו והתאימו אחיזה, טווח או חלופה עם איש מקצוע; אל תקפיצו את המוט מהחזה."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/barbell-bench-press.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של לחיצת חזה במוט עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "lat-pulldown",
    "name": "משיכת פולי עליון",
    "group": "back",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר פולי עליון",
    "focus": [
      "גב",
      "יד קדמית"
    ],
    "description": "משיכה בישיבה מלמעלה כלפי הגוף, לחיזוק שרירי הגב.",
    "steps": [
      "שבו יציב במכשיר והחזיקו במוט באחיזה עילית.",
      "משכו את המוט לכיוון קדמת הגוף כשהמרפקים יורדים לצדדים.",
      "החזירו את המוט למעלה באטיות ובשליטה."
    ],
    "cues": [
      "הראש נשאר בהמשך הגוף.",
      "בצעו משיכה נשלטת בלי תנופה או קשת מוגזמת בגב."
    ],
    "cautions": [
      {
        "title": "תנופה בגוף",
        "text": "אם צריך להישען או להתנדנד כדי להשלים את המשיכה, הפחיתו את ההתנגדות."
      },
      {
        "title": "כאב בכתף או בצוואר",
        "text": "אם התנועה מכאיבה, הפסיקו והתאימו את האחיזה או הטווח בעזרת מדריך."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/lat-pull-down.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של משיכת פולי עליון עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-leg-press",
    "name": "לחיצת רגליים במכונה",
    "group": "legs",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר לחיצת רגליים",
    "focus": [
      "ירכיים",
      "ישבן"
    ],
    "description": "דחיפת משטח בעזרת הרגליים כשהגב נתמך במשענת.",
    "steps": [
      "כוונו את המושב, הניחו כפות רגליים מלאות על המשטח והכירו את נצרות הבטיחות.",
      "כופפו ברכיים בשליטה, רק כל עוד האגן והגב נשארים נתמכים.",
      "דחפו בחזרה בתנועה חלקה בלי נעילה חדה של הברכיים."
    ],
    "cues": [
      "שמרו את הגב והאגן במגע עם המשענת.",
      "הראש נשאר נינוח ובהמשך הגב."
    ],
    "cautions": [
      {
        "title": "האגן מתרומם",
        "text": "אם האגן מתגלגל או הגב מתנתק מהמשענת, הקטינו את עומק הירידה והתאימו את המושב."
      },
      {
        "title": "כאב בברך או בירך",
        "text": "אם מופיע כאב, הפסיקו והתאימו עומס או טווח; אין צורך להגיע לעומק קבוע בכל מחיר."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/45-degree-leg-press.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של לחיצת רגליים במכונה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-seated-leg-curl",
    "name": "כפיפת ברכיים בישיבה",
    "group": "legs",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר כפיפת ברכיים בישיבה",
    "focus": [
      "ירך אחורית"
    ],
    "description": "כפיפת ברכיים כנגד רפידה, לחיזוק השרירים האחוריים של הירך.",
    "steps": [
      "כוונו את המושב והרפידות כך שהגב נתמך והרפידה התחתונה מונחת בנוחות מעל העקבים.",
      "כופפו את הברכיים ומשכו את הרפידה מטה ולאחור בתנועה נשלטת.",
      "חזרו באטיות לעמדת ההתחלה בלי להטיח את המשקולות."
    ],
    "cues": [
      "שמרו את האגן יציב ואת הגב צמוד למשענת.",
      "הימנעו מתנופה ומנעילה חזקה של הברכיים בחזרה."
    ],
    "cautions": [
      {
        "title": "התאמת המכשיר",
        "text": "אם הרפידה לוחצת במקום לא נוח או האגן מתרומם, עצרו וכוונו מחדש בעזרת מדריך."
      },
      {
        "title": "כאב בברך",
        "text": "אם הכפיפה מכאיבה, הפסיקו והתאימו את הטווח וההתנגדות לפני ניסיון נוסף."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/seated-leg-curl"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של כפיפת ברכיים בישיבה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-leg-extension",
    "name": "פשיטת ברכיים במכונה",
    "group": "legs",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר פשיטת ברכיים",
    "focus": [
      "ירך קדמית"
    ],
    "description": "יישור ברכיים בישיבה כנגד רפידה, לחיזוק קדמת הירך.",
    "steps": [
      "כוונו את המושב כך שציר המכשיר תואם לציר הברך והרפידה נמצאת בקדמת השוק.",
      "יישרו את הברכיים בתנועה חלקה ונשלטת, תוך שמירה על ישיבה יציבה.",
      "הורידו את הרגליים באטיות לעמדת ההתחלה."
    ],
    "cues": [
      "התאמת ציר המכשיר לברך קודמת לבחירת עומס.",
      "בחרו התנגדות שמאפשרת שליטה מלאה לאורך התנועה."
    ],
    "cautions": [
      {
        "title": "ציר שאינו מתאים לברך",
        "text": "אם אי אפשר להתאים את המושב והציר לגוף, אל תמשיכו לפני בדיקה עם מדריך."
      },
      {
        "title": "כאב או עומס חריג",
        "text": "אם מופיע כאב בברך, הפסיקו; אל תנסו להתגבר עליו באמצעות תנופה או תוספת משקל."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/leg-extension.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של פשיטת ברכיים במכונה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-chest-press",
    "name": "לחיצת חזה במכונה בשכיבה",
    "group": "chest",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר לחיצת חזה בשכיבה",
    "focus": [
      "חזה",
      "יד אחורית",
      "כתפיים"
    ],
    "description": "לחיצה בשכיבה במסלול של מכונה, עם תמיכה לגב ולפלג הגוף העליון.",
    "steps": [
      "שכבו במכשיר כך שהידיות מעט מתחת לקו הכתפיים והגב נתמך.",
      "אחזו בידיות, יצבו את השכמות ודחפו את הידיות מעלה.",
      "החזירו את הידיות באטיות בלי לאבד את התמיכה של הגב."
    ],
    "cues": [
      "כפות הרגליים נשארות יציבות.",
      "הימנעו מקשת מוגזמת בגב התחתון."
    ],
    "cautions": [
      {
        "title": "מנח הידיות",
        "text": "אם תנוחת הידיות דורשת מתיחה לא נוחה בכתף, עצרו והתאימו את המנח או בחרו מכונה אחרת עם מדריך."
      },
      {
        "title": "כאב בכתף",
        "text": "אם הלחיצה מכאיבה, הפסיקו והתאימו טווח או חלופה עם מדריך."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/hammer-strength-bench-press.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של לחיצת חזה במכונה בשכיבה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "cable-triceps-pushdown",
    "name": "פשיטת מרפקים עם חבל",
    "group": "arms",
    "level": "beginner",
    "equipment": [
      "cable"
    ],
    "equipmentLabel": "כבל עליון וחבל",
    "focus": [
      "יד אחורית"
    ],
    "description": "פשיטת מרפקים מטה מול גלגלת עליונה, עם חבל בשתי הידיים.",
    "steps": [
      "חברו חבל לגלגלת עליונה ועמדו מול המכשיר באחיזה נוחה.",
      "שמרו את הזרועות יציבות ופשטו את המרפקים כדי להוריד את החבל.",
      "חזרו באטיות לכפיפה, בלי למשוך את הכתפיים קדימה."
    ],
    "cues": [
      "עיקר התנועה מגיע מהמרפקים.",
      "אל תנעצו את המרפקים בנעילה חזקה."
    ],
    "cautions": [
      {
        "title": "הכתפיים או הגוף משתלטים",
        "text": "אם צריך להתנדנד או להטות את הכתפיים קדימה כדי לדחוף, הפחיתו את המשקל."
      },
      {
        "title": "כאב במרפק",
        "text": "אם הפשיטה מכאיבה, עצרו והתאימו את האחיזה והטווח לפני המשך."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/rope-tricep-extension.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של פשיטת מרפקים עם חבל עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "cable-face-pull",
    "name": "משיכת חבל לגובה הפנים",
    "group": "shoulders",
    "level": "intermediate",
    "equipment": [
      "cable"
    ],
    "equipmentLabel": "כבל וחבל בגובה הפנים",
    "focus": [
      "כתף אחורית",
      "גב עליון"
    ],
    "description": "משיכה אופקית של חבל לכיוון הפנים, לחיזוק הכתף האחורית.",
    "steps": [
      "כוונו את הגלגלת לגובה הפנים ועמדו יציב, עם רגל אחת מעט לפני השנייה.",
      "משכו את החבל לכיוון הפנים כשהמרפקים גבוהים והראש נשאר יציב.",
      "החזירו את הידיים לפנים באטיות ובשליטה."
    ],
    "cues": [
      "החבל נשאר בקירוב בגובה העיניים.",
      "אל תקרבו את הראש אל החבל או תקשתו את הגב כדי להשלים את המשיכה."
    ],
    "cautions": [
      {
        "title": "קשת בגב או הישענות",
        "text": "אם קשה לשמור על גוף יציב, הפחיתו עומס והתאימו את העמידה עם מדריך."
      },
      {
        "title": "כאב בכתף או בצוואר",
        "text": "אם התנועה מכאיבה, עצרו ובחרו טווח או תרגיל חלופי המתאים לכם."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/cable-face-pull"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של משיכת חבל לגובה הפנים עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-seated-calf-raise",
    "name": "הרמת עקבים במכונה בישיבה",
    "group": "legs",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר תאומים בישיבה",
    "focus": [
      "שוקיים"
    ],
    "description": "עלייה על כריות כף הרגל בישיבה כנגד התנגדות המכשיר.",
    "steps": [
      "שבו עם כריות כפות הרגליים על המשטח והירכיים מתחת לרפידה.",
      "הרימו את העקבים בתנועה חלקה, תוך שמירה על מגע קדמת כף הרגל.",
      "הורידו את העקבים באטיות בטווח נוח ונשלט."
    ],
    "cues": [
      "התנועה מתרחשת בקרסוליים בלי קפיצות.",
      "הדחיפה מגיעה מכרית כף הרגל, ולא מקצות האצבעות בלבד."
    ],
    "cautions": [
      {
        "title": "אי־נוחות בכף הרגל",
        "text": "אם הורדת העקבים יוצרת מתיחה לא נוחה בכף הרגל, הקטינו טווח; בכאב עצרו."
      },
      {
        "title": "תנופה",
        "text": "אם המשקל גורם לקפיצות או לאובדן שליטה, הפחיתו התנגדות לפני המשך."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/seated-calf-raise.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של הרמת עקבים במכונה בישיבה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-shoulder-press",
    "name": "לחיצת כתפיים במכונה",
    "group": "shoulders",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר לחיצת כתפיים",
    "focus": [
      "כתפיים",
      "יד אחורית"
    ],
    "description": "לחיצה של הידיות מעל הראש תוך ישיבה נתמכת.",
    "steps": [
      "כוונו את המושב כך שהידיות מתחילות בקירוב בגובה הכתפיים.",
      "אחזו בידיות ודחפו מעל הראש בתנועה נוחה ונשלטת.",
      "הורידו באטיות חזרה לגובה ההתחלה."
    ],
    "cues": [
      "אל תדחפו את הראש קדימה.",
      "הימנעו מנעילה חדה של המרפקים."
    ],
    "cautions": [
      {
        "title": "לחץ בצוואר או בכתף",
        "text": "אם מופיע כאב או לחץ לא נוח, הפסיקו והתאימו את המושב, הטווח או התרגיל."
      },
      {
        "title": "קושי להגיע מעל הראש",
        "text": "אם אי אפשר ללחוץ בלי לפצות בהקשתת הגב, הפחיתו טווח ובקשו התאמה ממדריך."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/machine-shoulder-press"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של לחיצת כתפיים במכונה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-hip-abduction",
    "name": "הרחקת ירכיים במכונה",
    "group": "legs",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר הרחקת ירכיים",
    "focus": [
      "צדי הישבן",
      "ירכיים"
    ],
    "description": "פתיחת הרגליים כנגד רפידות המכשיר תוך ישיבה יציבה.",
    "steps": [
      "שבו עם הגב נתמך והניחו את הרגליים מול הרפידות לפי מבנה המכשיר.",
      "הרחיקו את הרגליים בהדרגה, בלי לשנות את תנוחת האגן.",
      "החזירו את הרפידות באטיות לעמדת ההתחלה."
    ],
    "cues": [
      "שמרו על מנח גב נוח ויציב.",
      "בחרו טווח שבו אין צורך להטות או לסובב את האגן."
    ],
    "cautions": [
      {
        "title": "הגב מתקשת",
        "text": "אם פתיחת הרגליים גורמת לקשת מוגזמת בגב, הקטינו טווח והתאימו את הישיבה."
      },
      {
        "title": "כאב בירך או במפשעה",
        "text": "אם התנועה מכאיבה, עצרו והתאימו טווח או חלופה; אין צורך לפתוח עד קצה המכשיר."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/hip-abduction-machine.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של הרחקת ירכיים במכונה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "barbell-romanian-deadlift",
    "name": "דדליפט רומני עם מוט",
    "group": "legs",
    "level": "intermediate",
    "equipment": [
      "barbell"
    ],
    "equipmentLabel": "מוט",
    "focus": [
      "ירך אחורית",
      "ישבן"
    ],
    "description": "תנועת ציר בירך עם מוט קרוב לגוף, לחיזוק השרשרת האחורית.",
    "steps": [
      "התחילו בעמידה עם המוט קרוב לירכיים, אחיזה סגורה וברכיים רכות.",
      "שלחו את האגן לאחור והורידו את המוט קרוב לרגליים, רק בטווח שבו הגב נשאר נשלט.",
      "החזירו את האגן קדימה וחזרו לעמידה בלי להישען לאחור בסיום."
    ],
    "cues": [
      "המוט נשאר קרוב לגוף.",
      "כף הרגל נשארת במגע מלא עם הרצפה."
    ],
    "cautions": [
      {
        "title": "תנועת ציר שאינה מוכרת",
        "text": "אם אינכם מכירים את התנועה, תרגלו קודם ללא עומס ועם מדריך; אין משקל מומלץ אוטומטית."
      },
      {
        "title": "גב מתעגל או כואב",
        "text": "אם הגב מאבד שליטה, הקטינו טווח ועומס; אם יש כאב, הפסיקו ובדקו התאמה."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/romanian-deadlift"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של דדליפט רומני עם מוט עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "barbell-back-squat",
    "name": "סקוואט עם מוט על הגב",
    "group": "legs",
    "level": "advanced",
    "equipment": [
      "barbell"
    ],
    "equipmentLabel": "מוט, מתקן סקוואט ומוטות בטיחות",
    "focus": [
      "ירכיים",
      "ישבן",
      "ליבה"
    ],
    "description": "סקוואט עם מוט על הגב העליון, למי שכבר שולט בטכניקת התנועה.",
    "steps": [
      "מקמו את המוט על שרירי הגב העליון בתוך מתקן מתאים, ולא על הצוואר.",
      "כופפו ירכיים וברכיים יחד וירדו באטיות לטווח שנשלט בנוחות.",
      "דחפו את הרצפה וחזרו לעמידה יציבה; בסיום החזירו את המוט למתקן."
    ],
    "cues": [
      "הברכיים נעות בכיוון כפות הרגליים.",
      "שמרו את כפות הרגליים יציבות ואת התנועה נשלטת."
    ],
    "cautions": [
      {
        "title": "טכניקה והשגחה",
        "text": "אם אין ניסיון קודם, בחרו תחילה גרסה ללא מוט ותרגלו עם מדריך. הגדירו אמצעי בטיחות לפני הוספת עומס."
      },
      {
        "title": "כאב או אובדן שליטה",
        "text": "אם הגב או הברכיים כואבים, או היציבה משתנה תחת העומס, הפסיקו והתאימו את התרגיל."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/squat.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של סקוואט עם מוט על הגב עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "machine-reverse-fly",
    "name": "פרפר אחורי במכונה",
    "group": "shoulders",
    "level": "beginner",
    "equipment": [
      "machine"
    ],
    "equipmentLabel": "מכשיר פרפר אחורי",
    "focus": [
      "כתף אחורית",
      "גב עליון"
    ],
    "description": "פתיחת הידיים לאחור מול מכונה, כשהחזה נתמך בכרית.",
    "steps": [
      "שבו מול המכשיר עם החזה על הכרית והחזיקו בידיות שלפניכם.",
      "פתחו את הידיים לצדדים ולאחור עם מרפקים רכים.",
      "החזירו את הידיות באטיות, בלי לדחוף את הראש לפנים."
    ],
    "cues": [
      "החזה נשאר נתמך והגוף יציב.",
      "התנועה מגיעה מהכתפיים בלי כיווץ מוגזם של השכמות."
    ],
    "cautions": [
      {
        "title": "הראש נדחף קדימה",
        "text": "אם התנועה דורשת פיצוי של הראש או הגוף, הפחיתו משקל והתאימו את המושב."
      },
      {
        "title": "כאב בכתף",
        "text": "אם הפתיחה לאחור מכאיבה, עצרו והקטינו טווח או בחרו חלופה עם מדריך."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/machine-reverse-fly"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של פרפר אחורי במכונה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "bodyweight-push-up",
    "name": "שכיבות סמיכה",
    "group": "chest",
    "level": "intermediate",
    "equipment": [],
    "equipmentLabel": "ללא ציוד",
    "focus": [
      "חזה",
      "יד אחורית",
      "ליבה"
    ],
    "description": "דחיפת הגוף מהרצפה תוך שמירה על קו גוף יציב.",
    "steps": [
      "הניחו ידיים מתחת לכתפיים, האריכו את הרגליים והביטו לרצפה.",
      "כופפו את המרפקים והורידו את הגוף כיחידה אחת בטווח נשלט.",
      "דחפו את הרצפה וחזרו לעמדת ההתחלה בלי לשקוע בגב."
    ],
    "cues": [
      "המרפקים אינם נפתחים ישר לצדדים בצורת האות טי.",
      "הראש, הגב והאגן נשארים בקו יציב."
    ],
    "cautions": [
      {
        "title": "הגב שוקע או הגוף מאבד קו",
        "text": "אם קשה לשמור על גוף יציב, עברו לגרסה מול קיר או משטח מוגבה לפני גרסת הרצפה."
      },
      {
        "title": "כאב בשורש כף היד או בכתף",
        "text": "אם יש כאב, הפסיקו והתאימו את מנח הידיים או בחרו חלופה מתאימה."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/push-up.html"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של שכיבות סמיכה עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "barbell-hip-thrust",
    "name": "הרמת אגן עם מוט",
    "group": "legs",
    "level": "intermediate",
    "equipment": [
      "barbell",
      "bench"
    ],
    "equipmentLabel": "מוט וספסל יציב",
    "focus": [
      "ישבן",
      "ירכיים"
    ],
    "description": "הרמת האגן כאשר הגב העליון נתמך בספסל והמוט מעל האגן.",
    "steps": [
      "התמקמו עם הגב העליון על ספסל יציב, כפות הרגליים על הרצפה והמוט מונח בנוחות באזור האגן.",
      "דחפו דרך כפות הרגליים והרימו את האגן בעזרת הישבן.",
      "הורידו את האגן באטיות, בלי לאבד שליטה במוט."
    ],
    "cues": [
      "בחלק העליון, כוונו לקו נוח מהכתפיים דרך האגן אל הברכיים.",
      "אל תקשתו את הגב התחתון כדי להרים גבוה יותר."
    ],
    "cautions": [
      {
        "title": "תמיכה יציבה וטכניקה",
        "text": "אם הספסל זז או התנועה אינה מוכרת, עצרו ותרגלו תחילה ללא מוט עם מדריך."
      },
      {
        "title": "כאב בגב או לחץ מהמוט",
        "text": "אם יש כאב, עצרו והתאימו עומס, ריפוד או גרסה חלופית; אין לדחוף דרך הכאב."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/barbell-hip-thrust"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של הרמת אגן עם מוט עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  },
  {
    "id": "cable-straight-arm-pulldown",
    "name": "משיכת חבל בידיים כמעט ישרות",
    "group": "back",
    "level": "intermediate",
    "equipment": [
      "cable"
    ],
    "equipmentLabel": "כבל עליון וחבל",
    "focus": [
      "גב",
      "כתפיים"
    ],
    "description": "משיכה של חבל לכיוון הירכיים, תוך שמירה על מרפקים כמעט ישרים.",
    "steps": [
      "עמדו מול גלגלת עליונה עם חבל, אחזו בו והטו מעט את הגוף מהירכיים.",
      "השאירו כפיפה קלה במרפקים ומשכו את החבל לכיוון הירכיים.",
      "החזירו את הידיים לפנים ולמעלה באטיות בלי לשנות את מנח הגב."
    ],
    "cues": [
      "שמרו את הבטן פעילה בלי קשת מוגזמת בגב.",
      "הראש נשאר בהמשך הגוף והמרפקים אינם מבצעים כפיפה גדולה."
    ],
    "cautions": [
      {
        "title": "הגב מפצה על המשיכה",
        "text": "אם צריך להתנדנד או להקשית את הגב כדי להשלים את התנועה, הפחיתו עומס וטווח."
      },
      {
        "title": "כאב בכתף",
        "text": "אם הרמת הידיים או המשיכה מכאיבות, הפסיקו ובקשו התאמת טווח או תרגיל חלופי."
      }
    ],
    "category": "strength",
    "source": {
      "label": "Muscle & Strength",
      "url": "https://www.muscleandstrength.com/exercises/rope-straight-arm-pull-down"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "הדגמה מצולמת של משיכת חבל בידיים כמעט ישרות עם מתאמן אמיתי. המשקל המופיע בסרטון אינו המלצה למשקל אישי."
  }
]);
