// Original Hebrew summaries; videos remain on their original publishers.
// Introductory sample doses are not personal clinical prescriptions.
window.VEXYRO_HOME_EXERCISES = Object.freeze([
  {
    "id": "march-in-place",
    "name": "צעידה במקום",
    "category": "warmup",
    "equipment": [],
    "equipmentLabel": "ללא ציוד",
    "focus": [
      "endurance",
      "general-fitness"
    ],
    "steps": [
      "עמדו בנוחות והתחילו לצעוד במקום בקצב קל.",
      "הרימו והניחו כל רגל לסירוגין.",
      "הניעו זרועות בקצב הצעדים, במרפקים כפופים."
    ],
    "cues": [
      "התחילו בהדרגה ושמרו על ידיים רפויות.",
      "צעדו בלי לקפוץ."
    ],
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "מדריכה מצולמת צועדת במקום ומרימה רגליים לסירוגין.",
    "source": {
      "label": "Bromley Healthcare — Standing Marching",
      "url": "https://www.bromleyhealthcare.org.uk/falls-and-fracture-prevention-exercises/"
    },
    "defaultPrescription": {
      "kind": "timed",
      "durationSeconds": 60,
      "restSeconds": 15
    },
    "description": "צעידה קלה בעמידה. מתרגלים קצב ותיאום.",
    "group": "cardio",
    "level": "beginner",
    "cautions": [
      {
        "title": "שיווי משקל",
        "text": "אם יש סחרחורת או חוסר יציבות, עצרו ובקשו התאמה."
      }
    ]
  },
  {
    "id": "sit-to-stand",
    "name": "קימה וישיבה",
    "category": "strength",
    "equipment": [
      "chair"
    ],
    "equipmentLabel": "כיסא יציב ללא גלגלים",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "steps": [
      "שבו בקדמת הכיסא, רגליים ברוחב האגן.",
      "הטו מעט קדימה וקומו לאט בעזרת הרגליים.",
      "התיישרו וחזרו לישיבה בשליטה."
    ],
    "cues": [
      "מבט קדימה; בלי לצנוח לכיסא."
    ],
    "video": {
      "kind": "embed",
      "embedUrl": "https://players.brightcove.net/79855382001/EkC1XU82e_default/index.html?videoId=1763916272001",
      "watchUrl": "https://www.nhs.uk/live-well/exercise/strength-and-flex-exercise-plan-how-to-videos/",
      "provider": "NHS",
      "title": "NHS Strength and flexibility: sit to stand",
      "language": "en",
      "human": true,
      "contextNote": "ההדגמה מצולמת על ספסל; בבית משתמשים בכיסא יציב."
    },
    "videoDescription": "מדריכה מצולמת קמה מספסל וחוזרת לישיבה בשליטה.",
    "source": {
      "label": "NHS — Sit to stand",
      "url": "https://www.nhs.uk/live-well/exercise/strength-and-flex-exercise-plan-how-to-videos/"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "description": "קימה מכיסא וחזרה לישיבה. תרגול בסיסי לרגליים.",
    "group": "legs",
    "level": "beginner",
    "cautions": [
      {
        "title": "קושי בקימה",
        "text": "אם הקימה דורשת תנופה או מכאיבה לברך, בקשו התאמה."
      }
    ]
  },
  {
    "id": "wall-push-up",
    "name": "כפיפות מרפקים מול קיר",
    "category": "strength",
    "equipment": [
      "wall"
    ],
    "equipmentLabel": "קיר פנוי ויציב",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "steps": [
      "עמדו במרחק זרוע מהקיר, ידיים בגובה החזה.",
      "כופפו מרפקים לאט והתקרבו לקיר.",
      "דחפו בחזרה לעמידת המוצא."
    ],
    "cues": [
      "גב ישר ומרפקים סמוכים לגוף."
    ],
    "video": {
      "kind": "embed",
      "embedUrl": "https://players.brightcove.net/79855382001/EkC1XU82e_default/index.html?videoId=1763919379001",
      "watchUrl": "https://www.nhs.uk/live-well/exercise/strength-and-flex-exercise-plan-how-to-videos/",
      "provider": "NHS",
      "title": "NHS Strength and flexibility: standing press-up",
      "language": "en",
      "human": true,
      "contextNote": "בסרטון נעזרים בגזע יציב; כאן מבצעים את התנועה מול קיר יציב."
    },
    "videoDescription": "מדריכה מצולמת מכופפת ומיישרת מרפקים מול משטח אנכי יציב.",
    "source": {
      "label": "NHS — Standing press-up",
      "url": "https://www.nhs.uk/live-well/exercise/strength-and-flex-exercise-plan-how-to-videos/"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "description": "דחיפת הגוף מול קיר. מפעילה חזה וזרועות.",
    "group": "chest",
    "level": "beginner",
    "cautions": [
      {
        "title": "שורש כף היד והכתף",
        "text": "אם הדחיפה מכאיבה לשורש כף היד או לכתף, עצרו ובקשו התאמה."
      }
    ]
  },
  {
    "id": "calf-raise",
    "name": "עלייה על קצות האצבעות",
    "category": "strength",
    "equipment": [
      "chair"
    ],
    "equipmentLabel": "כיסא יציב ללא גלגלים",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "steps": [
      "עמדו ואחזו במשענת כיסא יציב.",
      "הרימו עקבים באיטיות בטווח נוח.",
      "הורידו אותם בשליטה."
    ],
    "cues": [
      "עלו ורדו בלי ניתור."
    ],
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "מדריכה מצולמת מרימה ומורידה עקבים בעמידה עם תמיכה.",
    "source": {
      "label": "Bromley Healthcare — Heel raises",
      "url": "https://www.bromleyhealthcare.org.uk/falls-and-fracture-prevention-exercises/"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "description": "הרמת עקבים בעמידה. מפעילה את שרירי השוק.",
    "group": "legs",
    "level": "beginner",
    "cautions": [
      {
        "title": "קרסול ויציבות",
        "text": "אם יש כאב בקרסול או קושי להתייצב, עצרו ובקשו התאמה."
      }
    ]
  },
  {
    "id": "side-leg-raise",
    "name": "הרמת רגל הצידה",
    "category": "strength",
    "equipment": [
      "chair"
    ],
    "equipmentLabel": "כיסא יציב ללא גלגלים",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "steps": [
      "אחזו במשענת כיסא בעמידה זקופה.",
      "הרימו רגל הצידה בטווח נוח.",
      "החזירו לאט והחליפו צד."
    ],
    "cues": [
      "אגן ישר; בלי להטות את הגוף."
    ],
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "מדריכה מרימה רגל הצידה, באחיזה בכיסא.",
    "source": {
      "label": "NHS — Sideways leg lift",
      "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "description": "הרמת רגל הצידה בעמידה. מפעילה את צד הירך.",
    "group": "legs",
    "level": "beginner",
    "cautions": [
      {
        "title": "הטיית הגוף",
        "text": "אם צריך להישען הצידה או מופיע כאב בירך, עצרו ובקשו טווח מותאם."
      }
    ]
  },
  {
    "id": "seated-march",
    "name": "צעידה בישיבה",
    "category": "strength",
    "equipment": [
      "chair"
    ],
    "equipmentLabel": "כיסא יציב ללא גלגלים",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "steps": [
      "שבו זקוף ואחזו בצידי הכיסא.",
      "הרימו רגל בברך כפופה, בטווח נוח.",
      "הניחו בשליטה והחליפו רגל."
    ],
    "cues": [
      "בלי להישען לאחור."
    ],
    "video": {
      "kind": "direct",
      "src": "https://cdnapisec.kaltura.com/p/2207941/sp/220794100/playManifest/entryId/1_eq6xgtbo/flavorId/1_5f3sgelj/format/url/protocol/https/a.mp4",
      "watchUrl": "https://health.clevelandclinic.org/chair-exercises-for-seniors",
      "provider": "Cleveland Clinic",
      "title": "Seated marching",
      "language": "en",
      "human": true
    },
    "videoDescription": "אישה מצולמת יושבת בכיסא ומרימה ברך כפופה בכל פעם.",
    "source": {
      "label": "Cleveland Clinic — Marching",
      "url": "https://health.clevelandclinic.org/chair-exercises-for-seniors"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "description": "הרמת ברכיים לסירוגין בישיבה. מפעילה את אזור הירך.",
    "group": "legs",
    "level": "beginner",
    "cautions": [
      {
        "title": "כאב בירך או בגב",
        "text": "אם ההרמה מכאיבה לירך או לגב, עצרו ובקשו התאמת טווח."
      }
    ]
  },
  {
    "id": "seated-rotation",
    "name": "סיבוב גו בישיבה",
    "category": "mobility",
    "equipment": [
      "chair"
    ],
    "equipmentLabel": "כיסא יציב ללא גלגלים",
    "focus": [
      "flexibility",
      "general-fitness"
    ],
    "steps": [
      "שבו זקוף, רגליים ברצפה וזרועות מוצלבות על החזה.",
      "סובבו את הגו לצד בטווח נוח והחזיקו חמש שניות.",
      "חזרו למרכז ועברו לצד השני."
    ],
    "cues": [
      "האגן והרגליים נשארים במקום."
    ],
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "אדם מצולם יושב ומסובב את פלג הגוף העליון לצדדים, עם זרועות מוצלבות.",
    "source": {
      "label": "South Tees NHS — Seated rotations",
      "url": "https://www.southtees.nhs.uk/resources/seated-rotations/"
    },
    "defaultPrescription": {
      "kind": "hold",
      "reps": 5,
      "perSide": true,
      "holdSeconds": 5,
      "restSeconds": 45
    },
    "description": "סיבוב הגו בישיבה. מתרגלים תנועתיות בלי להזיז את האגן.",
    "group": "mobility",
    "level": "beginner",
    "cautions": [
      {
        "title": "סיבוב מכאיב",
        "text": "אם הסיבוב מעורר כאב בגב או קיימת הגבלה על סיבוב, בקשו התאמה."
      }
    ]
  },
  {
    "id": "chest-open",
    "name": "פתיחת חזה בישיבה",
    "category": "mobility",
    "equipment": [
      "chair"
    ],
    "equipmentLabel": "כיסא יציב ללא גלגלים",
    "focus": [
      "flexibility",
      "general-fitness"
    ],
    "steps": [
      "שבו זקוף, ללא הישענות למשענת.",
      "משכו כתפיים לאחור ולמטה ופתחו זרועות לצדדים.",
      "הרימו בעדינות את החזה והחזיקו חמש עד עשר שניות."
    ],
    "cues": [
      "מתיחה נוחה בלבד, בלי להרים כתפיים."
    ],
    "video": {
      "kind": "none",
      "provider": "לא זמין",
      "title": "אין סרטון לאפליקציה"
    },
    "videoDescription": "מדריכה מצולמת יושבת ומדגימה פתיחת זרועות ומתיחת חזה.",
    "source": {
      "label": "Bromley Healthcare — Chest Stretch",
      "url": "https://www.bromleyhealthcare.org.uk/falls-and-fracture-prevention-exercises/"
    },
    "defaultPrescription": {
      "kind": "hold",
      "reps": 5,
      "perSide": false,
      "holdSeconds": 5,
      "restSeconds": 45
    },
    "description": "פתיחת חזה בישיבה. תנועה עדינה של הכתפיים.",
    "group": "mobility",
    "level": "beginner",
    "cautions": [
      {
        "title": "כאב בכתף",
        "text": "אם פתיחת הזרועות מכאיבה לכתף, הפסיקו ובקשו התאמה."
      }
    ]
  },
  {
    "id": "bodyweight-squat",
    "name": "סקוואט במשקל הגוף",
    "category": "strength",
    "equipment": [],
    "equipmentLabel": "ללא ציוד",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "כיפוף ויישור הרגליים בעמידה. מפעיל ירכיים וישבן.",
    "group": "legs",
    "level": "beginner",
    "steps": [
      "עמדו ברגליים מעט רחבות מרוחב הכתפיים.",
      "כופפו ירכיים וברכיים ורדו רק לעומק נשלט.",
      "חזרו לעמידה באיטיות."
    ],
    "cues": [
      "גב במנח טבעי וברכיים בכיוון כפות הרגליים."
    ],
    "source": {
      "label": "Mayo Clinic — Squat exercise",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/squat/vid-20084663"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_17rfuezw",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/squat/vid-20084663",
      "provider": "Mayo Clinic",
      "title": "Squat exercise",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "עומק הירידה",
        "text": "אם הברכיים כואבות או קורסות פנימה, עצרו ובקשו התאמה של העומק."
      }
    ],
    "videoDescription": "מדריכה מצולמת מבצעת סקוואט ללא משקולות, במבט קדמי וצידי."
  },
  {
    "id": "forward-lunge",
    "name": "מכרע קדמי",
    "category": "strength",
    "equipment": [],
    "equipmentLabel": "ללא ציוד",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "צעד לפנים וכיפוף הרגליים. משלב עבודת רגליים ושליטה בשיווי המשקל.",
    "group": "legs",
    "level": "intermediate",
    "steps": [
      "עמדו בנוחות וצעדו קדימה ברגל אחת.",
      "כופפו ברכיים בטווח נוח, כשהברך הקדמית בכיוון כף הרגל.",
      "חזרו לעמידה והחליפו רגל."
    ],
    "cues": [
      "שמרו גב ניטרלי ותנועה איטית."
    ],
    "source": {
      "label": "Mayo Clinic — Lunge exercise",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/lunge/vid-20084662"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_bom3f3w5",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/lunge/vid-20084662",
      "provider": "Mayo Clinic",
      "title": "Lunge exercise",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "ברך ושיווי משקל",
        "text": "אם יש כאב בברך או אובדן יציבות, הפסיקו ובקשו גרסה נתמכת."
      }
    ],
    "videoDescription": "מדריכה מצולמת צועדת קדימה, מבצעת מכרע וחוזרת לעמידה."
  },
  {
    "id": "step-up",
    "name": "עלייה למדרגה",
    "category": "strength",
    "equipment": [
      "step"
    ],
    "equipmentLabel": "מדרגה נמוכה ויציבה",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "עלייה וירידה ממדרגה. מפעילה את הירך והישבן.",
    "group": "legs",
    "level": "beginner",
    "steps": [
      "הניחו את כל כף הרגל על מדרגה נמוכה ויציבה.",
      "עלו בעיקר בעזרת הרגל שעל המדרגה.",
      "רדו בשליטה והחליפו את הרגל המובילה."
    ],
    "cues": [
      "העדיפו מדרגה נמוכה המאפשרת תנועה נשלטת."
    ],
    "source": {
      "label": "Mayo Clinic — Step-up exercise",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/step-up/vid-20084661"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_dhn2s7m4",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/step-up/vid-20084661",
      "provider": "Mayo Clinic",
      "title": "Step-up exercise",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "מדרגה ויציבות",
        "text": "אם אי אפשר להניח כף רגל מלאה או לשמור על יציבות, התאימו גובה ותמיכה."
      }
    ],
    "videoDescription": "מדריכה מצולמת עולה למדרגה נמוכה ויורדת לאחור בשליטה."
  },
  {
    "id": "abdominal-crunch",
    "name": "כפיפת בטן קצרה",
    "category": "strength",
    "equipment": [
      "mat"
    ],
    "equipmentLabel": "מזרן",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "הרמה קצרה של הראש והכתפיים בשכיבה. הדגש הוא עבודה של שרירי הבטן.",
    "group": "core",
    "level": "beginner",
    "steps": [
      "שכבו עם ברכיים כפופות וכפות רגליים על הרצפה.",
      "שלבו זרועות על החזה והרימו מעט ראש וכתפיים.",
      "חזרו באיטיות לרצפה."
    ],
    "cues": [
      "אל תמשכו את הראש בידיים; נשמו בחופשיות."
    ],
    "source": {
      "label": "Mayo Clinic — Abdominal crunch",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/abdominal-crunch/vid-20084664"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_6ksqo2x0",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/abdominal-crunch/vid-20084664",
      "provider": "Mayo Clinic",
      "title": "Abdominal crunch",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "צוואר וגב",
        "text": "אם הצוואר או הגב כואבים, הפסיקו ובקשו תרגיל ליבה חלופי."
      }
    ],
    "videoDescription": "מדריכה מצולמת שוכבת על מזרן ומרימה מעט את הראש והכתפיים."
  },
  {
    "id": "dumbbell-biceps-curl",
    "name": "כפיפת מרפק עם משקולת",
    "category": "strength",
    "equipment": [
      "dumbbells"
    ],
    "equipmentLabel": "משקולת יד",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "כפיפת המרפק כנגד משקולת. מפעילה את קדמת הזרוע.",
    "group": "arms",
    "level": "beginner",
    "steps": [
      "אחזו משקולת קלה כשהכף פונה קדימה.",
      "כופפו את המרפק בלי להרחיקו מהגוף.",
      "הורידו את המשקולת באיטיות."
    ],
    "cues": [
      "שורש כף יד ישר וללא תנופה."
    ],
    "source": {
      "label": "Mayo Clinic — Biceps curl with dumbbell",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/biceps-curl/vid-20084675"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_hmm42xy6",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/biceps-curl/vid-20084675",
      "provider": "Mayo Clinic",
      "title": "Biceps curl with dumbbell",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "מרפק ואחיזה",
        "text": "אם האחיזה או המרפק כואבים, הפסיקו ובקשו התאמת משקל או אחיזה."
      }
    ],
    "videoDescription": "מדריכה מצולמת מכופפת ומיישרת מרפק עם משקולת יד."
  },
  {
    "id": "dumbbell-bent-over-row",
    "name": "חתירה בכפיפה עם משקולת",
    "category": "strength",
    "equipment": [
      "dumbbells"
    ],
    "equipmentLabel": "משקולת יד",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "משיכת משקולת כשהגו מוטה לפנים. מפעילה את הגב העליון ואחורי הכתף.",
    "group": "back",
    "level": "intermediate",
    "steps": [
      "כופפו מעט ברכיים והטו את הגו מהירכיים.",
      "משכו מרפק לאחור כשהגב נשאר במנח טבעי.",
      "הורידו את המשקולת בשליטה."
    ],
    "cues": [
      "אל תגלגלו את הכתף לפנים."
    ],
    "source": {
      "label": "Mayo Clinic — Bent-over row with dumbbell",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/bent-over-row/vid-20084680"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_oxe53z16",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/bent-over-row/vid-20084680",
      "provider": "Mayo Clinic",
      "title": "Bent-over row with dumbbell",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "תנוחת הגב",
        "text": "אם קשה להחזיק גב יציב או מופיע כאב, בקשו גרסה נתמכת."
      }
    ],
    "videoDescription": "מדריכה מצולמת מטה את הגו ומושכת משקולת כלפי הגוף."
  },
  {
    "id": "dumbbell-calf-raise",
    "name": "הרמת עקבים עם משקולות",
    "category": "strength",
    "equipment": [
      "dumbbells"
    ],
    "equipmentLabel": "משקולות יד",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "הרמת עקבים בעמידה עם משקולות. מוסיפה התנגדות לעבודת השוק.",
    "group": "legs",
    "level": "intermediate",
    "steps": [
      "עמדו ברגליים ברוחב הכתפיים ומשקולות לצד הגוף.",
      "עלו באיטיות על קדמת כפות הרגליים.",
      "הורידו עקבים בשליטה."
    ],
    "cues": [
      "ברכיים ישרות, ללא ניתור."
    ],
    "source": {
      "label": "Mayo Clinic — Calf raise with dumbbell",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/calf-raise/vid-20084681"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_8gfi9r45",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/calf-raise/vid-20084681",
      "provider": "Mayo Clinic",
      "title": "Calf raise with dumbbell",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "יציבות עם משקל",
        "text": "אם קשה להתייצב, הניחו את המשקולות ובקשו גרסה עם תמיכה."
      }
    ],
    "videoDescription": "מדריכה מצולמת אוחזת משקולות ומרימה עקבים בעמידה."
  },
  {
    "id": "dumbbell-triceps-extension",
    "name": "פשיטת מרפק בשכיבה עם משקולת",
    "category": "strength",
    "equipment": [
      "dumbbells",
      "mat"
    ],
    "equipmentLabel": "משקולת יד ומזרן",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "יישור מרפק בשכיבה כשהזרוע פונה מעלה. מפעיל את אחורי הזרוע.",
    "group": "arms",
    "level": "intermediate",
    "steps": [
      "שכבו על הגב והפנו זרוע עם משקולת קלה לתקרה.",
      "ממרפק כפוף, ישרו אותו באיטיות.",
      "כופפו שוב בלי להזיז את הזרוע העליונה."
    ],
    "cues": [
      "תנועה איטית; אפשר לייצב את הזרוע ביד השנייה."
    ],
    "source": {
      "label": "Mayo Clinic — Triceps extension with dumbbell",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/triceps-extension/vid-20084676"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_0jd9byl8",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/triceps-extension/vid-20084676",
      "provider": "Mayo Clinic",
      "title": "Triceps extension with dumbbell",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "שליטה במשקולת",
        "text": "אם הזרוע אינה יציבה או יש כאב במרפק, עצרו ובקשו משקל או גרסה מתאימים."
      }
    ],
    "videoDescription": "מדריכה מצולמת שוכבת ומיישרת מרפק כלפי מעלה עם משקולת."
  },
  {
    "id": "dumbbell-reverse-fly",
    "name": "הרחקת זרועות בישיבה עם משקולות",
    "category": "strength",
    "equipment": [
      "dumbbells",
      "chair"
    ],
    "equipmentLabel": "משקולות יד וכיסא יציב",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "פתיחת זרועות כשהגו מוטה לפנים בישיבה. מפעילה גב עליון ואחורי כתפיים.",
    "group": "shoulders",
    "level": "intermediate",
    "steps": [
      "שבו והטו את הגו קדימה, עם משקולות לצד השוקיים.",
      "הרימו זרועות לצדדים עד גובה הכתפיים, במרפקים מעט כפופים.",
      "הורידו באיטיות."
    ],
    "cues": [
      "ללא תנופה וללא עיגול או הקשתה של הגב."
    ],
    "source": {
      "label": "Mayo Clinic — Reverse fly with dumbbell",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/reverse-fly/vid-20084679"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_xa0381hj",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/reverse-fly/vid-20084679",
      "provider": "Mayo Clinic",
      "title": "Reverse fly with dumbbell",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "גב או כתף",
        "text": "אם התנוחה מכאיבה או קשה לשלוט בתנועה, בקשו גרסה נתמכת ומשקל קל יותר."
      }
    ],
    "videoDescription": "מדריכה מצולמת יושבת בכפיפה ופותחת זרועות לצדדים עם משקולות."
  },
  {
    "id": "dumbbell-squat",
    "name": "סקוואט עם משקולות",
    "category": "strength",
    "equipment": [
      "dumbbells"
    ],
    "equipmentLabel": "משקולות יד",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "סקוואט כשמשקולות מוחזקות לצד הגוף. מוסיף התנגדות לשרירי הרגליים והישבן.",
    "group": "legs",
    "level": "intermediate",
    "steps": [
      "עמדו ברוחב הכתפיים ומשקולות לצד הגוף.",
      "רדו בהדרגה בכיפוף ירכיים וברכיים עד עומק נשלט.",
      "חזרו לעמידה בלי תנופה."
    ],
    "cues": [
      "גב במנח טבעי וברכיים בכיוון כפות הרגליים."
    ],
    "source": {
      "label": "Mayo Clinic — Squat with dumbbell",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/squat/vid-20084682"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_4l265yn0",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/squat/vid-20084682",
      "provider": "Mayo Clinic",
      "title": "Squat with dumbbell",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "שליטה לפני משקל",
        "text": "אם הסקוואט ללא משקל קשה או מכאיב, אל תוסיפו משקולות לפני התאמה."
      }
    ],
    "videoDescription": "מדריכה מצולמת מבצעת סקוואט ומשקולות בידיה לצד הגוף."
  },
  {
    "id": "band-seated-row",
    "name": "חתירה בישיבה עם גומייה",
    "category": "strength",
    "equipment": [
      "band",
      "mat"
    ],
    "equipmentLabel": "גומיית התנגדות ומזרן",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "משיכת גומייה בישיבה כשהיא עוברת סביב כפות הרגליים. מפעילה את הגב העליון.",
    "group": "back",
    "level": "beginner",
    "steps": [
      "שבו בברכיים מעט כפופות והניחו גומייה מאובטחת סביב כפות הרגליים.",
      "משכו מרפקים לאחור בלי להישען לאחור.",
      "החזירו ידיים קדימה בשליטה."
    ],
    "cues": [
      "גב ניטרלי ותנועה חלקה."
    ],
    "source": {
      "label": "Mayo Clinic — Seated row with resistance tubing",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/seated-row/vid-20084669"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_o9fnd2py",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/seated-row/vid-20084669",
      "provider": "Mayo Clinic",
      "title": "Seated row with resistance tubing",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "גומייה ואחיזה",
        "text": "אם הגומייה מחליקה או התנוחה מכאיבה לגב, עצרו והתאימו את ההעמדה."
      }
    ],
    "videoDescription": "מדריכה מצולמת יושבת ומושכת גומייה מכפות הרגליים לכיוון הגוף."
  },
  {
    "id": "band-hip-abduction",
    "name": "הרמת רגל הצידה עם גומייה",
    "category": "strength",
    "equipment": [
      "band"
    ],
    "equipmentLabel": "גומיית התנגדות",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "הרמת הרגל הצידה כנגד גומייה. מפעילה את השרירים שבצד הירך.",
    "group": "legs",
    "level": "intermediate",
    "steps": [
      "הניחו לולאת גומייה סביב קרסול ואבטחו את הצד השני מתחת לכף הרגל הנגדית.",
      "הניעו את הרגל הצידה בלי להטות את הגו.",
      "החזירו לאט והחליפו צד."
    ],
    "cues": [
      "שמרו על יציבות וטווח נשלט."
    ],
    "source": {
      "label": "Mayo Clinic — Standing hip abduction with resistance tubing",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/standing-hip-abduction/vid-20084670"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_qnpzouxu",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/standing-hip-abduction/vid-20084670",
      "provider": "Mayo Clinic",
      "title": "Standing hip abduction with resistance tubing",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "איזון והתנגדות",
        "text": "אם הגומייה מושכת אתכם מאיזון או יש כאב בירך, עצרו ובקשו התאמה."
      }
    ],
    "videoDescription": "מדריכה מצולמת מרחיקה רגל הצידה כנגד גומייה סביב הקרסול."
  },
  {
    "id": "band-squat",
    "name": "סקוואט עם גומייה",
    "category": "strength",
    "equipment": [
      "band"
    ],
    "equipmentLabel": "גומיית התנגדות עם ידיות",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "סקוואט כשהגומייה מאובטחת מתחת לכפות הרגליים. מוסיף התנגדות לתנועת הקימה.",
    "group": "legs",
    "level": "intermediate",
    "steps": [
      "עמדו על מרכז הגומייה ואחזו בידיות סמוך לכתפיים.",
      "כופפו ירכיים וברכיים ורדו רק לעומק נשלט.",
      "חזרו לעמידה באיטיות."
    ],
    "cues": [
      "שמרו ברכיים בכיוון כפות הרגליים."
    ],
    "source": {
      "label": "Mayo Clinic — Squat with resistance tubing",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/squat/vid-20084672"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_x89s46iz",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/squat/vid-20084672",
      "provider": "Mayo Clinic",
      "title": "Squat with resistance tubing",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "קושי בתנועה",
        "text": "אם השליטה נפגעת או הברכיים כואבות, עצרו ובקשו תרגול ללא התנגדות."
      }
    ],
    "videoDescription": "מדריכה מצולמת מבצעת סקוואט עם גומייה מתחת לרגליים ובידיים."
  },
  {
    "id": "band-bent-over-row",
    "name": "חתירה בכפיפה עם גומייה",
    "category": "strength",
    "equipment": [
      "band"
    ],
    "equipmentLabel": "גומיית התנגדות",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "משיכת הגומייה כשהגו מוטה לפנים. מפעילה גב עליון ואחורי כתפיים.",
    "group": "back",
    "level": "intermediate",
    "steps": [
      "עמדו על מרכז הגומייה, כופפו מעט ברכיים והטו גו מהירכיים.",
      "משכו את הידיות לאחור, במרפקים סמוכים לגוף.",
      "שחררו את המשיכה באיטיות."
    ],
    "cues": [
      "גב במנח טבעי וללא תנופה."
    ],
    "source": {
      "label": "Mayo Clinic — Bent-over row with resistance tubing",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/bent-over-row/vid-20084668"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": false,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_npy57lhc",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/bent-over-row/vid-20084668",
      "provider": "Mayo Clinic",
      "title": "Bent-over row with resistance tubing",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "גב ואחיזה",
        "text": "אם הגב כואב או קשה לשמור על העמידה, בקשו גרסה נתמכת."
      }
    ],
    "videoDescription": "מדריכה מצולמת עומדת על גומייה ומושכת את ידיותיה לאחור."
  },
  {
    "id": "band-side-step",
    "name": "צעדי צד עם גומייה",
    "category": "strength",
    "equipment": [
      "band"
    ],
    "equipmentLabel": "גומיית לולאה לקרסוליים",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "צעדים קטנים הצידה כנגד גומייה. מתרגלים עבודת ירך ויציבות.",
    "group": "legs",
    "level": "intermediate",
    "steps": [
      "הניחו גומייה מתאימה סביב הקרסוליים וכופפו מעט ברכיים.",
      "צעדו הצידה בצעדים קטנים ונשלטים.",
      "חזרו בכיוון הנגדי בלי לנעול ברכיים."
    ],
    "cues": [
      "שמרו על צעדים חלקים ועל גוף יציב."
    ],
    "source": {
      "label": "Mayo Clinic — Hip abduction walk with resistance tubing",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/hip-abduction-walk/vid-20084671"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_44d9ak66",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/hip-abduction-walk/vid-20084671",
      "provider": "Mayo Clinic",
      "title": "Hip abduction walk with resistance tubing",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "אובדן יציבות",
        "text": "אם הגומייה גורמת למעידה או כאב בירך או בברך, עצרו ובקשו התאמה."
      }
    ],
    "videoDescription": "מדריכה מצולמת צועדת מצד לצד עם גומייה סביב הקרסוליים."
  },
  {
    "id": "band-hamstring-curl",
    "name": "כפיפת ברך בעמידה עם גומייה",
    "category": "strength",
    "equipment": [
      "band",
      "wall"
    ],
    "equipmentLabel": "גומיית התנגדות וקיר לתמיכה",
    "focus": [
      "strength",
      "general-fitness"
    ],
    "description": "קירוב העקב לישבן כנגד גומייה. מפעיל את אחורי הירך.",
    "group": "legs",
    "level": "intermediate",
    "steps": [
      "אבטחו גומייה סביב קרסול ומתחת לכף הרגל השנייה והיעזרו בקיר.",
      "כופפו את הברך והביאו את העקב לאחור בטווח נוח.",
      "הורידו בשליטה והחליפו רגל."
    ],
    "cues": [
      "גב יציב והרגל התומכת מעט כפופה."
    ],
    "source": {
      "label": "Mayo Clinic — Hamstring curl with resistance tubing",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/hamstring-curl/vid-20084673"
    },
    "defaultPrescription": {
      "kind": "reps",
      "reps": 5,
      "perSide": true,
      "secondsPerRep": 5,
      "restSeconds": 45
    },
    "video": {
      "kind": "embed",
      "embedUrl": "https://cdnapisec.kaltura.com/p/1825021/embedPlaykitJs/uiconf_id/49798893?iframeembed=true&entry_id=1_xevd1dm9",
      "watchUrl": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/hamstring-curl/vid-20084673",
      "provider": "Mayo Clinic",
      "title": "Hamstring curl with resistance tubing",
      "language": "en",
      "human": true
    },
    "cautions": [
      {
        "title": "ברך ואיזון",
        "text": "אם כיפוף הברך מכאיב או קשה להתייצב, הפסיקו ובקשו התאמת התנגדות."
      }
    ],
    "videoDescription": "מדריכה מצולמת מכופפת ברך לאחור כנגד גומייה תוך תמיכה."
  }
]);
