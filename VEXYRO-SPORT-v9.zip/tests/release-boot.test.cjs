const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'release-boot.js'), 'utf8');
function storage(initial = {}) {
  const values = new Map(Object.entries(initial));
  return {
    get length() { return values.size; },
    key(index) { return Array.from(values.keys())[index] ?? null; },
    getItem(key) { return values.get(key) ?? null; },
    setItem(key, value) { values.set(key, String(value)); },
    removeItem(key) { values.delete(key); },
  };
}
function boot(window) { vm.runInNewContext(source, { window }); }

test('first v8 launch clears all prior app data but leaves other websites untouched', () => {
  const localStorage = storage({
    'vexyro.design-profile.v1': '{"name":"previous"}',
    'vexyro.training-plan.v1': '{}',
    'vexyro.active-workout.v1': '{}',
    'vexyro.workout-history.v1': '{}',
    'vexyro.membership-choice.v1': '{}',
    'vexyro.cloud-sync.v1': '{}',
    'vexyro.reminders-sent.v1': '{}',
    'vexyro.release-id': '2026-11-16-v5',
    'other-app.preferences': 'preserve',
  });
  const sessionStorage = storage({ 'vexyro.temporary': 'old', 'other-app.session': 'yes' });
  const window = { localStorage, sessionStorage };
  boot(window);
  assert.equal(localStorage.getItem('vexyro.design-profile.v1'), null);
  assert.equal(localStorage.getItem('vexyro.training-plan.v1'), null);
  assert.equal(localStorage.getItem('vexyro.workout-history.v1'), null);
  assert.equal(localStorage.getItem('vexyro.cloud-sync.v1'), null);
  assert.equal(sessionStorage.getItem('vexyro.temporary'), null);
  assert.equal(localStorage.getItem('other-app.preferences'), 'preserve');
  assert.equal(sessionStorage.getItem('other-app.session'), 'yes');
  assert.equal(localStorage.getItem('vexyro.release-id'), window.VEXYRO_RELEASE.id);
});

test('second v8 opening keeps the data created in v8', () => {
  const window = { localStorage: storage(), sessionStorage: storage() };
  boot(window);
  window.localStorage.setItem('vexyro.design-profile.v1', '{"name":"new"}');
  boot({ localStorage: window.localStorage, sessionStorage: window.sessionStorage });
  assert.equal(window.localStorage.getItem('vexyro.design-profile.v1'), '{"name":"new"}');
});

test('manually starting over removes newly stored app data', () => {
  const window = {localStorage: storage(), sessionStorage: storage()};
  boot(window);
  window.localStorage.setItem('vexyro.design-profile.v1', '{"name":"new"}');
  window.VEXYRO_RELEASE.resetLocalData();
  assert.equal(window.localStorage.getItem('vexyro.design-profile.v1'), null);
  assert.equal(window.localStorage.getItem('vexyro.release-id'), null);
  boot({localStorage: window.localStorage, sessionStorage: window.sessionStorage});
  assert.equal(window.localStorage.getItem('vexyro.release-id'), '2026-11-16-v8');
});
