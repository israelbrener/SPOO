const test = require('node:test');
const assert = require('node:assert/strict');
const date = require('../birthdate-utils.js');

test('simple Hebrew date formatting and parse round trip', () => {
  assert.equal(date.pretty(2013, 5, 22), '22 במאי 2013');
  assert.equal(date.iso(2013, 5, 22), '2013-05-22');
  assert.deepEqual(date.parse('2013-05-22'), { year: 2013, month: 5, day: 22 });
  assert.equal(date.parse('22/05/2013'), null);
});

test('leap day only exists on leap years; invalid day/month rejected', () => {
  const today = '2026-11-16';
  assert.equal(date.validBirthday(2012, 2, 29, today), true);
  assert.equal(date.validBirthday(2013, 2, 29, today), false);
  assert.equal(date.validBirthday(2000, 2, 29, today), true);
  assert.equal(date.validBirthday(1900, 2, 29, today), false);
  assert.equal(date.validBirthday(2013, 4, 31, today), false);
  assert.equal(date.validBirthday(2013, 13, 3, today), false);
  assert.equal(date.validBirthday(2013, 0, 3, today), false);
});

test('minimum age 1 and max 120 enforced based on birthday', () => {
  const today = '2026-11-16';
  assert.equal(date.validBirthday(2025, 11, 16, today), true);
  assert.equal(date.validBirthday(2025, 11, 17, today), false);
  assert.equal(date.validBirthday(2026, 1, 1, today), false);
  assert.equal(date.validBirthday(1905, 11, 17, today), true);
  assert.equal(date.validBirthday(1905, 11, 16, today), false);
  assert.equal(date.ageAt(2013, 11, 16, today), 13);
  assert.equal(date.ageAt(2013, 11, 17, today), 12);
});

test('reject future dates and calendar rollover', () => {
  assert.equal(date.validBirthday(2027, 1, 1, '2026-11-16'), false);
  assert.equal(date.validBirthday(2024, 2, 30, '2026-11-16'), false);
  assert.equal(date.validBirthday(2024, 6, 0, '2026-11-16'), false);
});
