const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const context=vm.createContext({console,Intl,Date,window:{}});
for(const file of ['data/exercises-home.js','data/exercises-gym.js','data/exercises.js','plan-legacy.js','plan-v2.js','training-options.js','plan-v3.js','plan-v4.js','plan-v5.js','schedule.js','plan.js','workout-engine.js']) {
  vm.runInContext(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),context,{filename:file});
}
const w=context.window;
const schedule=w.VEXYRO_SCHEDULE;
const plan=w.VEXYRO_PLAN;
const training=w.VEXYRO_TRAINING;
const catalog=w.VEXYRO_EXERCISES;
const profile={name:'Tester',birthDate:'1997-11-02',age:29,height:178,weight:75,gender:'male',trainingLocation:'both',workoutsPerWeek:3,goals:['strength'],experience:'intermediate'};
const chest=catalog.find(x=>x.group==='chest');
const legs=catalog.find(x=>x.group==='legs');
const back=catalog.find(x=>x.group==='back');
assert(chest&&legs&&back);
const exercises=[chest,legs,back];
const settings={startDate:'2026-11-16',screening:'clear',youthSupervision:false,
 equipment:[...new Set(exercises.flatMap(e=>e.equipment))],selectedExercises:exercises.map(e=>e.id),
 exerciseOptions:Object.fromEntries(exercises.map(e=>[e.id,training.defaultOptions(e)])),
 trainingDays:[0,3,5],bodyAreasByDay:{0:['chest'],3:['legs'],5:['back']},trainingTimes:{0:'18:00',3:'18:00',5:'18:00'}};
assert.equal(schedule.issue(profile,settings,catalog),null);
assert.equal(plan.validationIssue(profile,settings,'2026-11-16',catalog),null);
const built=plan.build(profile,settings,catalog,new Date('2026-11-16T10:00:00Z'));
assert.equal(built.schemaVersion,6);
assert.equal(built.days.filter(d=>d.session).length,3);
assert.equal(built.days.find(d=>d.session && d.session.areas.includes('chest')).session.startTime,'18:00');
assert.equal(plan.validSavedPlan(built,catalog),true);
const dayIndex=built.days.findIndex(d=>d.session);const active=w.VEXYRO_WORKOUT.create(built,dayIndex,catalog,Date.parse('2026-11-18T16:00:00Z'));assert.equal(active.scheduledDate,built.days[dayIndex].date);assert(w.VEXYRO_WORKOUT.restore(active,catalog));
assert.equal(built.days.filter(d=>d.session).every(d=>d.session.items.some(i=>i.phase==='main'&&catalog.find(e=>e.id===i.exerciseId).group===d.session.areas[0])),true);
const tampered=JSON.parse(JSON.stringify(built));tampered.days[0].title='wrong';assert.equal(plan.validSavedPlan(tampered,catalog),false);
const sameGroup={...settings,trainingDays:[0,2,4],bodyAreasByDay:{0:['chest'],2:['chest'],4:['chest']},trainingTimes:{0:'18:00',2:'18:00',4:'18:00'}};
assert.match(schedule.issue(profile,sameGroup).message,/עד 2/);
const overlap={...settings,trainingDays:[0,2,4],bodyAreasByDay:{0:['chest'],2:['chest'],4:['legs']},trainingTimes:{0:'18:00',2:'17:59',4:'18:00'}};
assert.match(schedule.issue(profile,overlap).message,/48/);
const exactly48={...overlap,trainingTimes:{0:'18:00',2:'18:00',4:'18:00'}};
assert.equal(schedule.issue(profile,exactly48),null);
const acrossWeek={...settings,trainingDays:[0,3,6],bodyAreasByDay:{0:['chest'],3:['legs'],6:['chest']},trainingTimes:{0:'18:00',3:'18:00',6:'18:00'}};
assert.match(schedule.issue(profile,acrossWeek).message,/48/);
const abProfile={...profile,workoutsPerWeek:3};
const ab={...settings,trainingDays:[0,2,4],bodyAreasByDay:{0:['core'],2:['core'],4:['core']},trainingTimes:{0:'18:00',2:'18:00',4:'18:00'}};
assert.equal(schedule.issue(abProfile,ab),null);
const wrongCount={...settings,trainingDays:[0,2]};assert.match(schedule.issue(profile,wrongCount).message,/בדיוק 3/);
const records=[{status:'complete',scheduledDate:'2026-11-01'},{status:'complete',scheduledDate:'2026-11-04'}];
assert.equal(schedule.streak({scheduleHistory:[{startDate:'2026-11-01',trainingDays:[0,3]}]},records,'2026-11-05',plan.addDays),5);
assert.equal(schedule.streak({scheduleHistory:[{startDate:'2026-11-01',trainingDays:[0,3]}]},records.filter(r=>r.scheduledDate!=='2026-11-04'),'2026-11-05',plan.addDays),0);
// The entire catalog can be selected; no arbitrary cap of 12 exercises remains.
const allAreas=[...new Set(catalog.map(ex=>ex.group))];
const fullProfile={...profile,workoutsPerWeek:1};
const fullSettings={...settings,trainingDays:[1],bodyAreasByDay:{1:allAreas},trainingTimes:{1:'18:00'},
  equipment:[...new Set(catalog.flatMap(ex=>ex.equipment))],
  selectedExercises:catalog.map(ex=>ex.id),
  exerciseOptions:Object.fromEntries(catalog.map(ex=>[ex.id,training.defaultOptions(ex)]))};
assert.equal(plan.validationIssue(fullProfile,fullSettings,'2026-11-16',catalog),null);
const fullPlan=plan.build(fullProfile,fullSettings,catalog,new Date('2026-11-16T10:00:00Z'));
const fullDay=fullPlan.days.find(day=>day.session);
assert.equal(fullDay.session.items.filter(item=>item.phase==='main').length,catalog.length);
assert.equal(plan.validSavedPlan(fullPlan,catalog),true);
// Scheduled rest days preserve a complete 31-day streak and display a blue flame.
let date='2026-10-04';const longRecords=[];
for(let n=0;n<31;n++,date=plan.addDays(date,1)){
  if(schedule.weekday(date)===0 || schedule.weekday(date)===3)
    longRecords.push({status:'complete',scheduledDate:date});
}
assert.equal(schedule.streak({scheduleHistory:[{startDate:'2026-10-04',trainingDays:[0,3]}]},longRecords,'2026-11-03',plan.addDays),31);
console.log('PASS: v6 plan build/restore; all catalog exercises; 48h including week wrap; 2/3 caps; 31-day streak');
